import os
import re
import newspaper
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("RagApp")
AV_STOCK_API_KEY = os.environ.get('AV_STOCK_API_KEY')


class RagTools:
    def parse_websites_content(links: list[str]) -> str:
        urls = get_the_urls(links)


def get_the_urls(links):
    urls = set()
    links = re.findall('http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', links)
    for link in links:
        try:
            la = link.split(",", 1)
            link = la[0]
            link = link.replace('],', '')
            link = link.replace(']', '')
            urls.add(link)
        except Exception as ex:
            print("Error while retrieving the urls", ex)
    return urls


def extract_page_content(urls):
    pages_content = ""
    for url in urls:
        try:
            article = newspaper.Article(url)
            article.download()
            article.parse()
            if len(article.text) > 0:
                pages_content = pages_content + article.text + '\n'
        except:
            continue
    return pages_content
