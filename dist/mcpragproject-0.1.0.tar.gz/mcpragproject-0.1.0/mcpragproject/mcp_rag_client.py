import streamlit as st
from mcp_rag_tools import RagTools as tools
if __name__ == '__main__':
    links = st.text_area(":blue[Add the sources for your Q&A session]", placeholder="Paste your links here")
    tools.parse_websites_content(links)

